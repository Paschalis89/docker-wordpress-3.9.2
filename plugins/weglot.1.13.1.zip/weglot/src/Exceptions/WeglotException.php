<?php

namespace Weglot\Exceptions;

class WeglotException extends \Exception
{
}
